export const BaseUrl = "https://api.coingecko.com/api/v3";
